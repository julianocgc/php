<html>
<title>Desenvolvendo Websites com PHP</title>
<body>

<?php
    echo `ls -l *.html`;
?>

</body>
</html>
