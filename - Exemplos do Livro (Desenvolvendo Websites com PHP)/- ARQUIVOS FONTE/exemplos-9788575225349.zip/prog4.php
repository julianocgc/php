<html>
<title>Desenvolvendo Websites com PHP</title>
<body>
<?php
   $time = "Gr�mio";
   $ano = 1983;

   $frase1 = "O $time � o melhor clube de futebol do mundo!";
   $frase2 = "O $time foi campe�o do mundo em $ano";

   echo "<h3>$frase1</h3>";
   echo "<h3>$frase2</h3>";
?>

</body>
</html>
