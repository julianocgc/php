<?php

   $x = "tri";
   echo "Eu sou " . $x . "color";

?>
