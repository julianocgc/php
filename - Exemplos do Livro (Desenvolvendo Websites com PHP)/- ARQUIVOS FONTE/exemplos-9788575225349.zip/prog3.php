<html>
<title>Desenvolvendo Websites com PHP</title>
<body>
<?php
   $dia = date ("d/m/Y");
   $base = 5.5;
   $altura = 10;

   $area = $base * $altura;
?>

</body>
</html>
