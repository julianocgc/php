<html>
<title>Desenvolvendo Websites com PHP</title>
<body>

<?php
    define ("meunome","Juliano");
    define ("peso",78);

    echo  "O meu nome � " . meunome;
    echo  "<br>";
    echo  "O meu peso � " . peso . " quilos";
?>

</body>
</html>
