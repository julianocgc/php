<?php
session_destroy( );
header ("Location: http://www.seusite.com.br ");
?>