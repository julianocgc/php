<html>
<title>Desenvolvendo Websites com PHP</title>
<body>
<?php

   $texto = "Porto Alegre";
   $futuro_identificador = "cidade";

   $$futuro_identificador = $texto;

   echo "<h2 align=center>";
   echo "Minha cidade � $cidade";
   echo "</h2>";

?>
</body>
</html>