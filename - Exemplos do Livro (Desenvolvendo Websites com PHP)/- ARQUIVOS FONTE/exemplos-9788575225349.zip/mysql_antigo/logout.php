<?php
	setcookie("nome_usuario");
	setcookie("senha_usuario");
	header ("Location: login.html");
?>

