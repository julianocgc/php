<?php

    $num = 7;

    $resultado = 8 * $num % 2;
    echo $resultado;
?>
