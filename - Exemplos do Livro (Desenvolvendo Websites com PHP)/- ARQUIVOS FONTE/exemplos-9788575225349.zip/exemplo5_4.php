<?php
// $opcao = "s";

switch ($opcao)
{
    case 's':
         echo  "Voc� escolheu a op��o SIM";
         break;
    case 'n':
         echo  " Voc� escolheu a op��o N�O ";
         break;
     default:
         echo  " A op��o digitada � inv�lida";
         break;      
}

?>
