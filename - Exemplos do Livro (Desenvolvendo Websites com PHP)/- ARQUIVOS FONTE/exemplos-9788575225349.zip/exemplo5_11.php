<?php

 $k = 1;

 while ($k < 20)
 {
     if ($vetor[$k] == "sair") 
     {  break;  }

     echo $vetor[$k] . "<br>";

      $k++;
}

?>
