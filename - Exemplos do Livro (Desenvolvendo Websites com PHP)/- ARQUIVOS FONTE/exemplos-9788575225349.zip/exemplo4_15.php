<html>
<title>Desenvolvendo Websites com PHP</title>
<body>

<?php
    $num = 15;
    $resultado1 = $num >> 1;   // desloca 1 bit para direita
    $resultado2 = $num << 2;   // desloca 2 bits para esquerda

    echo  $resultado1;
    echo "<br>";
    echo  $resultado2;
?>

</body>
</html>
