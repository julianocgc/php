<html>
<title>Desenvolvendo Websites com PHP</title>
<body>

<?php
    $num = 14;
    $deslocado = $num >> 1;   // desloca 1 bit para direita

    echo  $deslocado;
?>

</body>
</html>
