<?php

   $x = "tri";
   echo "Eu sou $xcolor";

?>
