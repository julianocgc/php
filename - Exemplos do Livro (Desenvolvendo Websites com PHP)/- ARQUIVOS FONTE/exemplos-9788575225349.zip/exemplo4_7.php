<?php

	$x = 50;
	$y = 2.35;

	$soma = (int) $y + $x;
	echo $soma;
?>
