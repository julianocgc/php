<?php

$mensagem = "<font color=\"#0000FF\">Teste</font>";

mail("joao@dominio.com.br", "Teste", $mensagem);

?>
