<?php

   function triplo ($numero)
   {
        $x = $numero * 3;
        return $x;
   }

   $valor = 5;
   echo "O triplo de $valor � " . triplo($valor);

?>
