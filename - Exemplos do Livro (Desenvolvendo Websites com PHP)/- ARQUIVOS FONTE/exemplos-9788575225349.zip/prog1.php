<html>
<title>Desenvolvendo Websites com PHP</title>
<body>
<?php

     // Legal, estou escrevendo meu primeiro programa em PHP
     
     echo  "<h2 align='center'>Parab�ns para mim!</h2>";

?>
</body>
</html>
