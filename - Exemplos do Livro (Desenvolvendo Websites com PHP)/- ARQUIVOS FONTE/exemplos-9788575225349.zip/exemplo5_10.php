<?php

$vetor = array (1, 2, 3, 4);
 
foreach ($vetor as $v)
{
    print "O valor atual do vetor � $v. <br>";
}


$a = array ( "um" => 1, "dois" => 2, "tres" => 3 );
 
 foreach($a as $chave => $valor) {
     print "\$a[$chave] => $valor.<br>";
 }

?>
