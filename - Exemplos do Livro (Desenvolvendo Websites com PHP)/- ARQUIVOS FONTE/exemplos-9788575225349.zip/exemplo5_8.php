<html>
<title>Desenvolvendo Websites com PHP</title>
<body>

<?php

     echo "Estou fazendo uma contagem regressiva: <br>";

      for($i=15 ; $i>=0 ; $i--)
      {
          echo $i . ", ";
      }

    echo "... FIM!";

?>

</body>
</html>
