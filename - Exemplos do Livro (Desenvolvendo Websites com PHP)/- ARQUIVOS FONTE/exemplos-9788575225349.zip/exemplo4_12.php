<?php

   $vetor = array (10,50,100,150,200);
   echo $vetor[2] . "<br>";

   $vet = array (1, 2, 3, "nome"=>"Joaquim");
   echo $vet[0] . "<br>";
   echo $vet["nome"];

?>
