<?php
// $numero = 1;

switch ($numero)
{
    case 0:
         echo  "n�mero vale 0";
         break;
    case 1:
         echo  "n�mero vale 1";
         break;
    case 2:
         echo  "n�mero vale 2";
         break;
}

?>
