<?php

  function teste ($time , $titulo = "Campe�o Mundial")
  {
       echo "O $time � $titulo <br>";
  }

   teste ("Flamengo" , "Campe�o Carioca");
   teste ("Atl�tico" , "Campe�o Mineiro");
   teste ("Gr�mio");

?>
