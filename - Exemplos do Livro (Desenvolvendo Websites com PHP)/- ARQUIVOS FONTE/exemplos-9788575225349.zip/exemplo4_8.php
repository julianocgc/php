<?php

	$time = "Gr�mio";
	$titulo = "Campe�o da Am�rica";
	$ano1 = 1983;
	$ano2 = 1995;
	echo "O $time foi $titulo em $ano1 e $ano2";

?>
