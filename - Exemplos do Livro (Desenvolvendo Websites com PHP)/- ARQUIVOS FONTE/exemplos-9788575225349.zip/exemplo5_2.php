<?php

    if ($nota == 10) 
    {
       echo "Parab�ns! <br>";
       echo "Voc� tirou a nota m�xima!";
    }

?>
