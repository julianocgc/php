<?php

$texto = "<img src=http://www.siteporno.com.br/foto1.jpg>";

$novo_texto =htmlspecialchars($texto);

echo $texto . "<br>";
echo  $novo_texto;


?>
