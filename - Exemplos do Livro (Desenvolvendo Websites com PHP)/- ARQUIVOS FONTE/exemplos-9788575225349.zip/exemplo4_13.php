<?php

    class Teste
    {
         function Saudacao()   {
             echo "Oi pessoal!";
         }

    }

     $objeto = new Teste;    // $objeto se torna uma inst�ncia da classe Teste
     $objeto -> Saudacao();

?>
