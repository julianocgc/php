<?php
    $palavra = "teste";
    $frase = "Isto � um $palavra";
    echo $frase;
?>
