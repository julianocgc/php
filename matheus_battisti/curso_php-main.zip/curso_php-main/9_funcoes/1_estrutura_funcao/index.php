<?php

  function teste() {

    // código

  }