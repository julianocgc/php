<?php
	function triplo ($numero)
	{
		$x = $numero * 3;
		return $x;
	}
	// programa principal
	$valor = 4;
	echo "O triplo de $valor � " . triplo($valor);
?>
