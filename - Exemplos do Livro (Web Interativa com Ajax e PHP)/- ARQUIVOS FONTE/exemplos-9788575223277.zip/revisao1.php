<?php
     // Estou programando em PHP!!!
     echo  "<h1 align='center'>Este � meu primeiro programa!</h1>";
?>
