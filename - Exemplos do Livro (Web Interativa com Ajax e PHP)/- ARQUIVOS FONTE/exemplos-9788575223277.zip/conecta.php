<?php
$servidor = "localhost";
$usuario = "usuario";
$senha = "senha";
$banco = "banco";

$con = mysqli_connect($servidor, $usuario, $senha, $banco);
?>
