<?php 
$nome = $_POST["nome"];
$x = $_POST["valor"];
$x2 = $x*$x;
echo "$nome, o servidor disse que o quadrado de $x vale $x2."; 
?>