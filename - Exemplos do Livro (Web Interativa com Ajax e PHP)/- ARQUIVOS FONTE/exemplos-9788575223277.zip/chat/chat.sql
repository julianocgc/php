CREATE TABLE chat (
	nome varchar(80),
	origem char NOT NULL,
	msg varchar(150)
);
