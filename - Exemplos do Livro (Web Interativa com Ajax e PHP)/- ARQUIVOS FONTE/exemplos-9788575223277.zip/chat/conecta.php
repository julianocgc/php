<?php
$servidor = "localhost";
$usuario = "usuario";
$senha = "senha";
$banco = "bdteste";

$con = mysqli_connect($servidor, $usuario, $senha, $banco);
?>
