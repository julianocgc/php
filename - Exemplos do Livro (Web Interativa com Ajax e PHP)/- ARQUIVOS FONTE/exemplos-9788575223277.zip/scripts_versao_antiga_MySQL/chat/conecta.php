<?php
$servidor = "localhost";
$usuario = "usuario";
$senha = "senha";
$banco = "test";
$con = mysql_connect($servidor, $usuario, $senha);
mysql_select_db($banco);
?>
