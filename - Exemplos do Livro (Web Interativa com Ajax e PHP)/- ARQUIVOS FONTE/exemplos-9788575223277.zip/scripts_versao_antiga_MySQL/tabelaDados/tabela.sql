CREATE TABLE produtos (
	codigo int NOT NULL AUTO_INCREMENT,
	nome varchar(100) NOT NULL,
	preco float NOT NULL,
	primary key(codigo)
);