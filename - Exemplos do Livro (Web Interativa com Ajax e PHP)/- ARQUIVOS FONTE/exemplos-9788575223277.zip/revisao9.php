<?php
	$nome = $_POST["nome"];
	echo "O nome digitado foi $nome";
?>
