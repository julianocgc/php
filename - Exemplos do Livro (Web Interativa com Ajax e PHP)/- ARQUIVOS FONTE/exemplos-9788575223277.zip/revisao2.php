<?php
	$time = "Gr�mio";
	$titulo = "Campe�o do Mundo";
	echo "O $time � $titulo";
?>
