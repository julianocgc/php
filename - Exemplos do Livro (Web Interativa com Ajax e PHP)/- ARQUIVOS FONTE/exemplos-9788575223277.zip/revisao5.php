<?php
	$numero = 1;
	do
	{
		echo "O valor atual do n�mero � $numero <br>";
		$numero++;
	} while ($numero<4);
?>
