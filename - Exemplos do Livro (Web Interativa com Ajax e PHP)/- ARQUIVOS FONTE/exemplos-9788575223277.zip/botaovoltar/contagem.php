<?php
$cont = $_GET["contador"];
?>
<HTML>
<HEAD></HEAD>
<BODY onload='parent.v_carregado();'>
<div id="divContagem"><?php echo $cont; ?></div>
</BODY>
</HTML>