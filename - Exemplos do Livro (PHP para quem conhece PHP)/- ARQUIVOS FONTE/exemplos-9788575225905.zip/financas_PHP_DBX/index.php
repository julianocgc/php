<html>
<head>
<title>Controle de gastos mensais</title>
</head>
<body>
<h1 align="center">Controle de gastos mensais</h1>
<p align="center">Digite seus dados de identifica��o para acessar o sistema:</p>
<hr>
<form method="POST" action="login.php">
  <p align="center">Usu�rio: <input type="text" name="usuario" size="20"></p>
  <p align="center">Senha: <input type="password" name="senha" size="20"></p>
  <p align="center"><input type="submit" value="Enviar" name="enviar"></p>
</form>
<hr>
</body>
</html>
