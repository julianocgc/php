<?php
	for($cont=0 ; $cont<10 ; $cont++)
	{
		echo "A vari�vel \$cont vale $cont";
		echo "<br>";
	}
?>

