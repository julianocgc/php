<html>
<body>
<?php
	$pais = "Brasil";
	$frase = "O $pais � pentacampe�o mundial de futebol";
	echo "<h2 align=center>$frase</h2>";
?>
</body>
</html>

