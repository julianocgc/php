<?php
	$nome = "Juliano";
	$futuro_identificador = "autor";
	$$futuro_identificador = $nome;
	echo "O nome do autor � ";
	echo $autor;
?>

