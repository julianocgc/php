<html>
<body>
<?php
	define ("meunome","Juliano Niederauer");
	define ("peso",90);
	echo  "O meu nome � " . meunome;
	echo  "<br>";
	echo  "O meu peso � " . peso . " quilos";
?>
</body>
</html>

