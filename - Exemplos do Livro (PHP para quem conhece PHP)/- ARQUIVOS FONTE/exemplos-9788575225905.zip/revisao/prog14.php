<?php
	$numero = 1;
	do
	{
		echo "O valor atual de n�mero � $numero <br>";
		$numero++;
	} while ($numero<4);
?>

