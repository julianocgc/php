<?php
	$cont = 1;
	while ($cont<100)
	{
		echo "O valor atual do contador � $cont <br>";
		$cont++;
	}
?>

