<?php
	$texto = "<img src='http://niederauer.com.br/figuras/livros/jovem103.jpg'>";
	$novo_texto =htmlspecialchars($texto);
	echo $texto . "<br>";
	echo  $novo_texto;
?>

