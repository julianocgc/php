<?php
	setcookie("email_usuario");
	setcookie("senha_usuario");
	header ("Location: login.html");
?>