<?php
$array = file ("teste.txt");
foreach ($array as $linha)
    echo $linha."<br>";
?>
