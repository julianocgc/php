<?php
$conteudo = file_get_contents ("teste.txt");
echo $conteudo;
?>
