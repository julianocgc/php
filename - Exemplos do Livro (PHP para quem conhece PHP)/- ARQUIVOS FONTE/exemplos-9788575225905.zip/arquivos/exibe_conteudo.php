<?php
$bytes = readfile ("teste.txt");
?>
