<html>
<head>
<title>Goleadores do Campeonato</title>
</head>
<body>

<h1 align="center">Goleadores do Campeonato</h1>
<p align="center">Os cinco jogadores que mais marcaram gols s�o:</p>
<div align="center">
  <center>
  <table border="1">
    <tr>
      <td bgcolor="#D6D6D6"><b>Jogador</b></td>
      <td bgcolor="#D6D6D6"><b>Time</b></td>
      <td bgcolor="#D6D6D6"><b>Gols</b></td>
    </tr>

    <?php include "lista_goleadores.inc"; ?>
    
  </table>
  </center>
</div>

</body>
</html>

