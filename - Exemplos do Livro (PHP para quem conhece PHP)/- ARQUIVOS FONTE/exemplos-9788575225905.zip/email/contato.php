<?php
$email_destino = array(
    "pergunta" => "perguntas@seusite.com.br",
    "reclamacao" => "reclamacoes@seusite.com.br",
    "suporte" => "suporte@seusite.com.br",
    "publicidade" => "anuncios@seusite.com.br",
    "webmaster" => "webmaster@seusite.com.br"
);

if(isset($_POST['nome']) && isset($_POST['email']) && isset($_POST['assunto']) && isset($_POST['mensagem']))
{
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];
}
else
{
    echo "Todos os campos devem ser preenchidos!";
    exit;
}

$msg = "Nome do usu�rio: $nome\n";
$msg .= "E-mail: $email\n";
$msg .= "Mensagem: $mensagem";
mail($email_destino[$assunto], "Mensagem do usu�rio", $msg, "From:contato@seusite.com.br","-r contato@seusite.com.br");

echo "Sua mensagem foi enviada com sucesso!";
?>