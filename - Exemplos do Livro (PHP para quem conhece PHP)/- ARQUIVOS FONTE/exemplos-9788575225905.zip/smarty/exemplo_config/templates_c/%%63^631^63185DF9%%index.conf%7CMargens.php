<?php $_config_vars = array (
  'titulo' => 'Esta � a Smarty!!!',
  'corFundo' => '#D6D6D6',
  'corTitulo' => '#0000FF',
  'margemSuperior' => '10',
  'margemEsquerda' => '10',
); ?>